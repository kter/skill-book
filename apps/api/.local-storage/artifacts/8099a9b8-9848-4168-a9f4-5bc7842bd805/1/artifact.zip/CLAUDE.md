# My coding rules

- Always add tests
